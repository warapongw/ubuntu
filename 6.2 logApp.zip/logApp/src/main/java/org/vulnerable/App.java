package org.vulnerable;

import static spark.Spark.*;
import spark.Filter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Hello world!
 *
 */
public class App 
{
    private static final Logger logger = LogManager.getLogger(App.class);

    public static void main( String[] args )
    {
	Connection c = null;
	try {
		Class.forName("org.postgresql.Driver");
		c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/logapp_database",
		"logapp_db_user", "password");
	} catch (Exception e) {
		e.printStackTrace();
		System.err.println(e.getClass().getName()+": "+e.getMessage());
		System.exit(0);
	}
	System.out.println("Opened database successfully");

	options("/*", (request,response)->{

		String accessControlRequestHeaders = request.headers("Access-Control-Request-Headers");
		if (accessControlRequestHeaders != null) {
			response.header("Access-Control-Allow-Headers", accessControlRequestHeaders);
		}

		String accessControlRequestMethod = request.headers("Access-Control-Request-Method");
		if(accessControlRequestMethod != null){
			response.header("Access-Control-Allow-Methods", accessControlRequestMethod);
		}
		response.header("Access-Control-Allow-Origin", "*");

		return "{\"message\":\"OK\"}";
    	});  

        System.out.println( "Hello World!" );
        before((request, response) -> response.type("application/json"));

        //Route to greeting
        get("/hello", (request, response) -> {
            logger.info("User agent -> {}", request.userAgent());

            return "{\"message\": \"Hello, World!\"}";
        });
        final Connection conn = c;
		post("/login",  (request, response) -> {
			response.header("Access-Control-Allow-Origin", "*");
	    	logger.info("Login body -> {}", request.body().toString());
	    	ObjectMapper objectMapper = new ObjectMapper();
	    	LoginClass loginInfo = objectMapper.readValue(request.body().toString(), LoginClass.class);
	    	logger.info("User login attempt -> {} ", loginInfo.getUsername());
	    	try {
	    	Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT * FROM Users WHERE username = '" + loginInfo.getUsername() + "' and password = '" +loginInfo.getPassword() + "';" );
		if (rs.next()){
			logger.info("ResultSet -> {} ", rs);
				response.status(200);
				logger.info("User login success -> {} ", loginInfo.getUsername());
	    		return "{\"message\": \"Success!\", \"username\":\""+loginInfo.getUsername()+"\"}";
	    		}
			logger.info("User login error -> {} ", loginInfo.getUsername());
			response.status(403);
    		return "{\"message\": \"Wrong username or password!\"}";
	    	} catch(Exception e) {
				response.status(403);
				logger.error("User login error -> {} ", loginInfo.getUsername());
	    		logger.error(e);
	    		return "{\"message\": \"Wrong username or password!\"}";
	    	}
	});

    }

	private static class LoginClass {
		String username;
		String password;

		public LoginClass() {}

		public LoginClass(String username, String password) {
			this.username = username;
			this.password = password;
		}
		
		public String getUsername() {return this.username;}

		public String getPassword() {return this.password;}
	}
}
