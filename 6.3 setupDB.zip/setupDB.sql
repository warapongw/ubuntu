CREATE USER logapp_db_user WITH PASSWORD 'password' SUPERUSER;
CREATE DATABASE logapp_database OWNER logapp_db_user;
\c logapp_database;
CREATE TABLE users(id SERIAL PRIMARY KEY, username VARCHAR(100), password VARCHAR(100));
INSERT INTO users VALUES (default, 'admin', 'password');
